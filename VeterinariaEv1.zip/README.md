# Nombre del Equipo
# Gruopo n4

## Integrantes
- Martin Cortes (marti.cortesg@duocuc.cl)
- Christian Montecinos (ch.montecinos@duocuc.cl)
- Alejandro Naranjo (alej.naranjo@duocuc.cl)

## Caso
Level-Up Gamer

## Descripción del caso
Tienda en línea de artículos para gamers (consolas, accesorios, sillas gamer).
La aplicación permite iniciar sesión, explorar el catálogo, agregar productos
al carrito y, para el rol administrador, gestionar el catálogo.

## Estructura del proyecto
src/
├── components/
│   ├── atoms/
│   ├── molecules/
│   ├── organisms/
│   └── templates/
└── pages/

## Tecnologías
- React + Vite
- React Bootstrap

## Cómo ejecutar el proyecto
npm install
npm run dev

## Material complementario
Carpeta de Drive con documentos del semestre (ERS y otros):
https://drive.google.com/drive/folders/XXXXXXXXXX