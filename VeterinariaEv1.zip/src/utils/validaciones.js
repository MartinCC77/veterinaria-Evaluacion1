
export function validarObligatorio(valor, nombreCampo) {
  if (valor.trim() === '') {
    return `${nombreCampo} es obligatorio.`
  }
  return ''
}


export function validarNombreDueno(valor) {
  if (valor.trim().length < 3) {
    return 'Ingresa tu nombre completo (mínimo 3 caracteres).'
  }
  return ''
}

export function validarCorreo(valor) {
  const patron = /^[^@\s]+@[^@\s]+\.[^@\s]+$/
  if (!patron.test(valor.trim())) {
    return 'Ingresa un correo válido (ejemplo: cliente@dominio.cl).'
  }
  return ''
}


export function validarMascota(valor) {
  return validarObligatorio(valor, 'El nombre de la mascota')
}


export function validarSeleccion(valor, nombreCampo) {
  if (valor === '') {
    return `Selecciona ${nombreCampo}.`
  }
  return ''
}


export function validarMotivo(valor) {
  if (valor.trim().length < 5) {
    return 'Describe el motivo con al menos 5 caracteres.'
  }
  return ''
}


export function validarFecha(valor, hoy) {
  if (valor === '') {
    return 'Selecciona una fecha.'
  }

  if (valor < hoy) {
    return 'La fecha no puede ser anterior a hoy.'
  }
  return ''
}


export function validarClave(valor) {
  if (valor.length < 6) {
    return 'La clave debe tener al menos 6 caracteres.'
  }
  return ''
}


export function validarMensaje(valor) {
  if (valor.trim().length < 10) {
    return 'Escribe un mensaje de al menos 10 caracteres.'
  }
  return ''
}


export function validarConfirmacionClave(clave, confirmacion) {
  if (clave !== confirmacion) {
    return 'Las claves no coinciden.'
  }
  return ''
}

export function validarNumeroPositivo(valor, nombreCampo) {
  if (String(valor).trim() === '') {
    return `${nombreCampo} es obligatorio.`
  }
  const numero = Number(valor)
  if (Number.isNaN(numero) || numero <= 0) {
    return `${nombreCampo} debe ser un número mayor que 0.`
  }
  return ''
}

export function validarPrecioOferta(precioOferta, precio) {
  const errorNumero = validarNumeroPositivo(precioOferta, 'El precio de oferta')
  if (errorNumero !== '') {
    return errorNumero
  }
  if (Number(precioOferta) >= Number(precio)) {
    return 'El precio de oferta debe ser menor que el precio normal.'
  }
  return ''
}